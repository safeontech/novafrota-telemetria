import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/device.dart';

class ApiException implements Exception {
  final int statusCode;
  final String message;
  const ApiException(this.statusCode, this.message);
  @override
  String toString() => 'ApiException($statusCode): $message';
}

class ApiService {
  final String baseUrl;
  final String token;

  const ApiService({required this.baseUrl, required this.token});

  Map<String, String> get _headers => {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      };

  Future<List<Device>> listDevices() async {
    final uri = Uri.parse('$baseUrl/api/devices');
    final res = await http.get(uri, headers: _headers);
    _check(res);
    final list = jsonDecode(res.body) as List<dynamic>;
    return list.map((e) => Device.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<Device> getDevice(String id) async {
    final uri = Uri.parse('$baseUrl/api/devices/$id');
    final res = await http.get(uri, headers: _headers);
    _check(res);
    return Device.fromJson(jsonDecode(res.body) as Map<String, dynamic>);
  }

  Future<Map<String, dynamic>> healthCheck() async {
    final uri = Uri.parse('$baseUrl/api/healthz');
    final res = await http.get(uri);
    _check(res);
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  void _check(http.Response res) {
    if (res.statusCode == 401) throw const ApiException(401, 'Unauthorized');
    if (res.statusCode >= 400) {
      throw ApiException(res.statusCode, res.body);
    }
  }
}
