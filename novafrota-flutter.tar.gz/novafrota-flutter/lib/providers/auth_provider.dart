import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _keyToken = 'nf_token';
const _keyBaseUrl = 'nf_base_url';
const _defaultBaseUrl = 'http://38.247.130.26';

class AuthProvider extends ChangeNotifier {
  String? _token;
  String _baseUrl = _defaultBaseUrl;
  bool _initialized = false;

  String? get token => _token;
  String get baseUrl => _baseUrl;
  bool get isAuthenticated => _token != null && _token!.isNotEmpty;
  bool get initialized => _initialized;

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString(_keyToken);
    _baseUrl = prefs.getString(_keyBaseUrl) ?? _defaultBaseUrl;
    _initialized = true;
    notifyListeners();
  }

  Future<void> signIn(String token, {String? baseUrl}) async {
    final prefs = await SharedPreferences.getInstance();
    _token = token;
    if (baseUrl != null && baseUrl.isNotEmpty) _baseUrl = baseUrl;
    await prefs.setString(_keyToken, token);
    await prefs.setString(_keyBaseUrl, _baseUrl);
    notifyListeners();
  }

  Future<void> signOut() async {
    final prefs = await SharedPreferences.getInstance();
    _token = null;
    await prefs.remove(_keyToken);
    notifyListeners();
  }

  Future<void> setBaseUrl(String url) async {
    final prefs = await SharedPreferences.getInstance();
    _baseUrl = url;
    await prefs.setString(_keyBaseUrl, url);
    notifyListeners();
  }
}
