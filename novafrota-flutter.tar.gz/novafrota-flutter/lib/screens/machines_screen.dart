import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../models/device.dart';
import '../providers/fleet_provider.dart';
import '../widgets/machine_card.dart';

class MachinesScreen extends StatefulWidget {
  const MachinesScreen({super.key});

  @override
  State<MachinesScreen> createState() => _MachinesScreenState();
}

class _MachinesScreenState extends State<MachinesScreen> {
  String _search = '';
  String _filter = 'all';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (context.read<FleetProvider>().state == LoadState.idle) {
        context.read<FleetProvider>().load();
      }
    });
  }

  List<Device> _filtered(List<Device> devices) {
    return devices.where((d) {
      if (_search.isNotEmpty) {
        final q = _search.toLowerCase();
        if (!d.label.toLowerCase().contains(q) && !d.id.toLowerCase().contains(q)) return false;
      }
      if (_filter == 'active') return d.isActive;
      if (_filter == 'stopped') return !d.isActive;
      if (_filter == 'overdue') return d.maintStatus == MaintStatus.overdue;
      if (_filter == 'upcoming') return d.maintStatus == MaintStatus.upcoming;
      return true;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Máquinas'),
        leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => context.pop()),
      ),
      body: Consumer<FleetProvider>(
        builder: (context, fleet, _) {
          final filtered = _filtered(fleet.devices);

          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                child: Column(
                  children: [
                    TextField(
                      onChanged: (v) => setState(() => _search = v),
                      style: const TextStyle(color: Colors.white, fontSize: 14),
                      decoration: InputDecoration(
                        hintText: 'Buscar máquina...',
                        hintStyle: const TextStyle(color: Color(0xFF475569)),
                        prefixIcon: const Icon(Icons.search, color: Color(0xFF475569), size: 18),
                        filled: true,
                        fillColor: const Color(0xFF1E293B),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFF334155))),
                        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFF334155))),
                        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFF1D4ED8))),
                        contentPadding: const EdgeInsets.symmetric(vertical: 10),
                      ),
                    ),
                    const SizedBox(height: 10),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          _FilterChip(label: 'Todas (${fleet.devices.length})', value: 'all', current: _filter, onTap: (v) => setState(() => _filter = v)),
                          _FilterChip(label: 'Ativas (${fleet.activeCount})', value: 'active', current: _filter, color: const Color(0xFF10B981), onTap: (v) => setState(() => _filter = v)),
                          _FilterChip(label: 'Paradas (${fleet.devices.length - fleet.activeCount})', value: 'stopped', current: _filter, color: const Color(0xFF6B7280), onTap: (v) => setState(() => _filter = v)),
                          _FilterChip(label: 'Próx. Rev. (${fleet.upcomingCount})', value: 'upcoming', current: _filter, color: const Color(0xFFF59E0B), onTap: (v) => setState(() => _filter = v)),
                          _FilterChip(label: 'Atrasadas (${fleet.overdueCount})', value: 'overdue', current: _filter, color: const Color(0xFFEF4444), onTap: (v) => setState(() => _filter = v)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                  ],
                ),
              ),
              Expanded(
                child: fleet.state == LoadState.loading && fleet.devices.isEmpty
                    ? const Center(child: CircularProgressIndicator())
                    : RefreshIndicator(
                        onRefresh: fleet.load,
                        child: filtered.isEmpty
                            ? ListView(
                                children: const [
                                  SizedBox(height: 80),
                                  Center(child: Icon(Icons.construction, color: Color(0xFF334155), size: 48)),
                                  SizedBox(height: 12),
                                  Center(child: Text('Nenhuma máquina encontrada', style: TextStyle(color: Color(0xFF64748B)))),
                                ],
                              )
                            : ListView.builder(
                                padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                                itemCount: filtered.length,
                                itemBuilder: (context, i) {
                                  final d = filtered[i];
                                  return MachineCard(device: d, onTap: () => context.push('/devices/${d.id}'));
                                },
                              ),
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final String value;
  final String current;
  final Color? color;
  final void Function(String) onTap;

  const _FilterChip({required this.label, required this.value, required this.current, this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final active = value == current;
    final c = color ?? const Color(0xFF3B82F6);
    return GestureDetector(
      onTap: () => onTap(value),
      child: Container(
        margin: const EdgeInsets.only(right: 6),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: active ? c.withOpacity(0.2) : const Color(0xFF1E293B),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: active ? c : const Color(0xFF334155)),
        ),
        child: Text(label, style: TextStyle(color: active ? c : const Color(0xFF94A3B8), fontSize: 12, fontWeight: FontWeight.w600)),
      ),
    );
  }
}
