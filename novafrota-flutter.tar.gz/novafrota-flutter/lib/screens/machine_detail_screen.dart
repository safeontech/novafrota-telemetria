import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/device.dart';
import '../services/api_service.dart';
import '../providers/auth_provider.dart';

class MachineDetailScreen extends StatefulWidget {
  final String deviceId;
  const MachineDetailScreen({super.key, required this.deviceId});

  @override
  State<MachineDetailScreen> createState() => _MachineDetailScreenState();
}

class _MachineDetailScreenState extends State<MachineDetailScreen> {
  Device? _device;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final auth = context.read<AuthProvider>();
      final api = ApiService(baseUrl: auth.baseUrl, token: auth.token!);
      final d = await api.getDevice(widget.deviceId);
      if (mounted) setState(() { _device = d; _loading = false; });
    } catch (e) {
      if (mounted) setState(() { _error = e.toString(); _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_device?.label ?? widget.deviceId),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _load),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text(_error!, style: const TextStyle(color: Color(0xFF94A3B8))))
              : _DeviceDetail(device: _device!),
    );
  }
}

class _DeviceDetail extends StatelessWidget {
  final Device device;
  const _DeviceDetail({required this.device});

  @override
  Widget build(BuildContext context) {
    final ms = device.maintStatus;
    final maintColor = ms == MaintStatus.overdue
        ? const Color(0xFFEF4444)
        : ms == MaintStatus.upcoming
            ? const Color(0xFFF59E0B)
            : const Color(0xFF10B981);
    final statusColor = device.isActive ? const Color(0xFF10B981) : const Color(0xFF6B7280);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: const Color(0xFF1E293B),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFF334155)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(color: const Color(0xFF0F172A), borderRadius: BorderRadius.circular(12)),
                      child: const Icon(Icons.construction, color: Color(0xFF3B82F6), size: 26),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(device.label, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700)),
                          if (device.machineModel != null)
                            Text(device.machineModel!, style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 13)),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: statusColor.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(width: 6, height: 6, decoration: BoxDecoration(color: statusColor, shape: BoxShape.circle)),
                          const SizedBox(width: 5),
                          Text(device.isActive ? 'Ativa' : 'Parada', style: TextStyle(color: statusColor, fontSize: 12, fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                const Divider(color: Color(0xFF334155), height: 1),
                const SizedBox(height: 20),
                const Text('HORÍMETRO', style: TextStyle(color: Color(0xFF475569), fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 1.5)),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      device.lastHourmeterMin != null ? '${device.hourmeterH.toStringAsFixed(1)}h' : '—',
                      style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w800, fontFamily: 'monospace'),
                    ),
                    if (ms != MaintStatus.ok)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                          color: maintColor.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          ms == MaintStatus.overdue ? 'REVISÃO ATRASADA' : 'REVISÃO PRÓXIMA',
                          style: TextStyle(color: maintColor, fontSize: 11, fontWeight: FontWeight.w700),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(
                    value: device.cycleProgress.clamp(0.0, 1.0),
                    backgroundColor: const Color(0xFF1F2937),
                    valueColor: AlwaysStoppedAnimation<Color>(maintColor),
                    minHeight: 10,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      device.lastHourmeterMin != null
                          ? '${(device.hourmeterH % device.limitH).toStringAsFixed(0)}h / ${device.limitH}h no ciclo'
                          : '',
                      style: const TextStyle(color: Color(0xFF64748B), fontSize: 11),
                    ),
                    Text(
                      device.lastHourmeterMin != null ? '${device.hoursRemaining.toStringAsFixed(0)}h restantes' : '',
                      style: TextStyle(color: maintColor, fontSize: 11, fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          if (device.lastLat != null || device.lastSeenAt != null)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF1E293B),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFF334155)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('LOCALIZAÇÃO & CONTATO', style: TextStyle(color: Color(0xFF475569), fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 1.5)),
                  const SizedBox(height: 14),
                  if (device.lastSeenAt != null)
                    _InfoRow(icon: Icons.access_time_rounded, label: 'Último contato', value: _formatDate(device.lastSeenAt!)),
                  if (device.lastLat != null)
                    _InfoRow(icon: Icons.location_on_outlined, label: 'Posição GPS', value: '${device.lastLat!.toStringAsFixed(5)}, ${device.lastLon!.toStringAsFixed(5)}'),
                  if (device.lastSpeedKmh != null)
                    _InfoRow(icon: Icons.speed_rounded, label: 'Velocidade', value: '${device.lastSpeedKmh!.toStringAsFixed(0)} km/h'),
                  if (device.lastIgnition != null)
                    _InfoRow(
                      icon: Icons.power_settings_new_rounded,
                      label: 'Ignição',
                      value: device.lastIgnition! ? 'LIGADA' : 'DESLIGADA',
                      valueColor: device.lastIgnition! ? const Color(0xFF10B981) : const Color(0xFF6B7280),
                    ),
                ],
              ),
            ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF1E293B),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFF334155)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('IDENTIFICAÇÃO', style: TextStyle(color: Color(0xFF475569), fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 1.5)),
                const SizedBox(height: 14),
                _InfoRow(icon: Icons.tag_rounded, label: 'ID do dispositivo', value: device.id, mono: true),
                if (device.model != null)
                  _InfoRow(icon: Icons.router_rounded, label: 'Modelo tracker', value: device.model!),
                if (device.machineType != null)
                  _InfoRow(icon: Icons.category_outlined, label: 'Tipo', value: device.machineType!),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(String iso) {
    final dt = DateTime.tryParse(iso)?.toLocal();
    if (dt == null) return iso;
    return '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}/${dt.year}  ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color? valueColor;
  final bool mono;

  const _InfoRow({required this.icon, required this.label, required this.value, this.valueColor, this.mono = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFF475569), size: 16),
          const SizedBox(width: 10),
          Expanded(child: Text(label, style: const TextStyle(color: Color(0xFF64748B), fontSize: 12))),
          Text(value, style: TextStyle(color: valueColor ?? Colors.white, fontSize: 12, fontWeight: FontWeight.w600, fontFamily: mono ? 'monospace' : null)),
        ],
      ),
    );
  }
}
