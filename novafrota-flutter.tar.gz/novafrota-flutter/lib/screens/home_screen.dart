import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../providers/fleet_provider.dart';
import '../providers/auth_provider.dart';
import '../widgets/kpi_card.dart';
import '../widgets/machine_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<FleetProvider>().load();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(color: const Color(0xFFDC2626), borderRadius: BorderRadius.circular(8)),
              child: const Center(child: Text('NF', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 11))),
            ),
            const SizedBox(width: 10),
            const Text('NOVA FROTA', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1, fontSize: 16)),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => context.push('/settings'),
          ),
        ],
      ),
      body: Consumer<FleetProvider>(
        builder: (context, fleet, _) {
          if (fleet.state == LoadState.loading && fleet.devices.isEmpty) {
            return const Center(child: CircularProgressIndicator());
          }
          if (fleet.state == LoadState.error && fleet.devices.isEmpty) {
            return _ErrorView(message: fleet.error ?? 'Erro desconhecido', onRetry: fleet.load);
          }
          return RefreshIndicator(
            onRefresh: fleet.load,
            color: const Color(0xFF1D4ED8),
            child: CustomScrollView(
              slivers: [
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                  sliver: SliverToBoxAdapter(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Visão Geral da Frota', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 4),
                        Text('${fleet.devices.length} máquinas cadastradas', style: const TextStyle(color: Color(0xFF64748B), fontSize: 12)),
                        const SizedBox(height: 16),
                        GridView.count(
                          crossAxisCount: 2,
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          crossAxisSpacing: 10,
                          mainAxisSpacing: 10,
                          childAspectRatio: 1.5,
                          children: [
                            KpiCard(
                              label: 'Ativas',
                              value: '${fleet.activeCount}',
                              sub: 'de ${fleet.devices.length} total',
                              icon: Icons.wifi_tethering_rounded,
                              color: const Color(0xFF10B981),
                            ),
                            KpiCard(
                              label: 'Horímetro Total',
                              value: '${fleet.totalHourmeterH.toStringAsFixed(0)}h',
                              sub: 'soma da frota',
                              icon: Icons.timer_outlined,
                              color: const Color(0xFF3B82F6),
                            ),
                            KpiCard(
                              label: 'Próx. Revisão',
                              value: '${fleet.upcomingCount}',
                              sub: '< 50h para revisão',
                              icon: Icons.build_outlined,
                              color: const Color(0xFFF59E0B),
                            ),
                            KpiCard(
                              label: 'Atrasadas',
                              value: '${fleet.overdueCount}',
                              sub: 'ação imediata',
                              icon: Icons.warning_amber_rounded,
                              color: const Color(0xFFEF4444),
                            ),
                          ],
                        ),
                        const SizedBox(height: 20),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('Máquinas', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
                            TextButton(
                              onPressed: () => context.push('/machines'),
                              child: const Text('Ver todas', style: TextStyle(color: Color(0xFF3B82F6), fontSize: 12)),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                      ],
                    ),
                  ),
                ),
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                  sliver: fleet.devices.isEmpty
                      ? SliverToBoxAdapter(
                          child: Center(
                            child: Padding(
                              padding: const EdgeInsets.all(32),
                              child: Column(
                                children: [
                                  const Icon(Icons.construction, color: Color(0xFF334155), size: 48),
                                  const SizedBox(height: 12),
                                  const Text('Nenhuma máquina encontrada', style: TextStyle(color: Color(0xFF64748B))),
                                ],
                              ),
                            ),
                          ),
                        )
                      : SliverList(
                          delegate: SliverChildBuilderDelegate(
                            (context, i) {
                              final d = fleet.devices[i];
                              return MachineCard(
                                device: d,
                                onTap: () => context.push('/devices/${d.id}'),
                              );
                            },
                            childCount: fleet.devices.length,
                          ),
                        ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _ErrorView({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.cloud_off_rounded, color: Color(0xFFEF4444), size: 48),
            const SizedBox(height: 16),
            Text(message, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFF94A3B8))),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh),
              label: const Text('Tentar novamente'),
            ),
          ],
        ),
      ),
    );
  }
}
