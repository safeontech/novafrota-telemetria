# Nova Frota Telemetria — Flutter

Android app for the Nova Frota fleet telemetry platform.

## Requirements

- Flutter SDK 3.10+  (https://flutter.dev/docs/get-started/install)
- Android Studio with Flutter & Dart plugins installed
- Android SDK / emulator or physical device

## Opening in Android Studio

1. Extract the archive
2. Open Android Studio →