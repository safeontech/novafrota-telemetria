import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'providers/auth_provider.dart';
import 'providers/fleet_provider.dart';
import 'services/api_service.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'screens/machines_screen.dart';
import 'screens/machine_detail_screen.dart';
import 'screens/settings_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final auth = AuthProvider();
  await auth.init();
  runApp(NovaFrotaApp(auth: auth));
}

class NovaFrotaApp extends StatelessWidget {
  final AuthProvider auth;
  const NovaFrotaApp({super.key, required this.auth});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: auth,
      child: Consumer<AuthProvider>(builder: (_, a, __) {
        final api = ApiService(baseUrl: a.baseUrl, token: a.token ?? '');
        return ChangeNotifierProvider(
          create: (_) => FleetProvider(api),
          child: MaterialApp.router(
            title: 'Nova Frota',
            debugShowCheckedModeBanner: false,
            theme: ThemeData(
              colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1D4ED8), brightness: Brightness.dark, surface: const Color(0xFF0F172A)),
              scaffoldBackgroundColor: const Color(0xFF0F172A),
              cardColor: const Color(0xFF1E293B),
              appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF0F172A), foregroundColor: Colors.white, elevation: 0, centerTitle: false),
              useMaterial3: true,
            ),
            routerConfig: GoRouter(
              redirect: (_, state) {
                final at = a.isAuthenticated;
                final onLogin = state.matchedLocation == '/login';
                if (!at && !onLogin) return '/login';
                if (at && onLogin) return '/';
                return null;
              },
              refreshListenable: a,
              routes: [
                GoRoute(path: '/login', builder: (_, __) => const LoginScreen()),
                GoRoute(path: '/', builder: (_, __) => const HomeScreen()),
                GoRoute(path: '/machines', builder: (_, __) => const MachinesScreen()),
                GoRoute(path: '/devices/:id', builder: (_, s) => MachineDetailScreen(deviceId: s.pathParameters['id']!)),
                GoRoute(path: '/settings', builder: (_, __) => const SettingsScreen()),
              ],
            ),
          ),
        );
      }),
    );
  }
}
